"""lyrics taken from https://www.azlyrics.com/"""

all_star = """Somebody once told me the world is gonna roll me
I ain't the sharpest tool in the shed
She was looking kind of dumb with her finger and her thumb
In the shape of an "L" on her forehead

Well, the years start coming and they don't stop coming
Fed to the rules and I hit the ground running
Didn't make sense not to live for fun
Your brain gets smart but your head gets dumb

So much to do, so much to see
So what's wrong with taking the back streets?
You'll never know if you don't go
You'll never shine if you don't glow

Hey, now, you're an All Star, get your game on, go play
Hey, now, you're a Rock Star, get the show on, get paid
And all that glitters is gold
Only shooting stars break the mold

It's a cool place and they say it gets colder
You're bundled up now wait 'til you get older
But the meteor men beg to differ
Judging by the hole in the satellite picture

The ice we skate is getting pretty thin
The water's getting warm so you might as well swim
My world's on fire. How about yours?
That's the way I like it and I'll never get bored.

Somebody once asked could I spare some change for gas
I need to get myself away from this place
I said yep, what a concept
I could use a little fuel myself
And we could all use a little change

Well, the years start coming and they don't stop coming
Fed to the rules and I hit the ground running
Didn't make sense not to live for fun
Your brain gets smart but your head gets dumb

So much to do, so much to see
So what's wrong with taking the back streets?
You'll never know if you don't go
You'll never shine if you don't glow.

And all that glitters is gold
Only shooting stars break the mold"""

downtown = """Making my way downtown
Walking fast
Faces pass
And I'm home-bound

Staring blankly ahead
Just making my way
Making a way
Through the crowd

And I need you
And I miss you
And now I wonder

If I could fall into the sky
Do you think time would pass me by?
'Cause you know I'd walk a thousand miles
If I could just see you tonight

It's always times like these
When I think of you
And I wonder if you ever think of me
'Cause everything's so wrong
And I don't belong
Living in your precious memory

'Cause I need you
And I miss you
And now I wonder

If I could fall into the sky
Do you think time would pass me by?
'Cause you know I'd walk a thousand miles
If I could just see you tonight

And I, I don't wanna let you know
I, I drown in your memory
I, I don't wanna let this go
I, I don't

Making my way downtown
Walking fast
Faces pass
And I'm home-bound

Staring blankly ahead
Just making my way
Making a way
Through the crowd

And I still need you
And I still miss you
And now I wonder

If I could fall into the sky
Do you think time would pass us by?
'Cause you know I'd walk a thousand miles
If I could just see you

If I could fall into the sky
Do you think time would pass me by?
'Cause you know I'd walk a thousand miles
If I could just see you
If I could just hold you tonight"""

synthetic_sample = """I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample

I am a synthetic sample"""

give_up = """We're no strangers to love
You know the rules and so do I
A full commitment's what I'm thinking of
You wouldn't get this from any other guy

I just wanna tell you how I'm feeling
Gotta make you understand

Never gonna give you up
Never gonna let you down
Never gonna run around and desert you
Never gonna make you cry
Never gonna say goodbye
Never gonna tell a lie and hurt you

We've known each other for so long
Your heart's been aching, but
You're too shy to say it
Inside, we both know what's been going on
We know the game and we're gonna play it

And if you ask me how I'm feeling
Don't tell me you're too blind to see

Never gonna give you up
Never gonna let you down
Never gonna run around and desert you
Never gonna make you cry
Never gonna say goodbye
Never gonna tell a lie and hurt you

Never gonna give you up
Never gonna let you down
Never gonna run around and desert you
Never gonna make you cry
Never gonna say goodbye
Never gonna tell a lie and hurt you

(Ooh, give you up)
(Ooh, give you up)
Never gonna give, never gonna give
(Give you up)
Never gonna give, never gonna give
(Give you up)

We've known each other for so long
Your heart's been aching, but
You're too shy to say it
Inside, we both know what's been going on
We know the game and we're gonna play it

I just wanna tell you how I'm feeling
Gotta make you understand

Never gonna give you up
Never gonna let you down
Never gonna run around and desert you
Never gonna make you cry
Never gonna say goodbye
Never gonna tell a lie and hurt you

Never gonna give you up
Never gonna let you down
Never gonna run around and desert you
Never gonna make you cry
Never gonna say goodbye
Never gonna tell a lie and hurt you

Never gonna give you up
Never gonna let you down
Never gonna run around and desert you
Never gonna make you cry
Never gonna say goodbye
Never gonna tell a lie and hurt you"""
